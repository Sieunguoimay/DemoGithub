<style>
.facebook-profile p, label{
    margin-bottom: 0px;
}
</style>
<div class="container facebook-profile">

    <div class="row mb-3">
        <div class="col-md-3 col-sm-3 col-xs-12 p-0 justify-content-center">
            <img src="{{$fbAccount['picture']['data']['url']}}" style="width:100%; border-radius:5px"/>
        </div>
        <div class="col-md-9 col-sm-9 col-xs-12 mt-xs-2">
            <h3>Facebook Profile</h3>
            <p><strong>User Name:</strong> {{$fbAccount['name']}}</p>
            <p><strong>Birthday:</strong> {{$fbAccount['birthday']}}</p>
            <p><strong>Hometown:</strong> {{$fbAccount['hometown']['name']}}</p>
            <div class="row mt-2">
                <div class="col-6">
                    <p><a href="{{$fbAccount['link']}}">Visit Facebook Profile <i class="fas fa-share" style="font-size:10px"></i></a></p>
                </div>
                <div class="col-6 p-0 text-right">
                    <a type="button" data-toggle="collapse" data-target="#div_new_feeds">
                        New Feeds <i class="fas fa-chevron-down"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row collapse"  id="div_new_feeds" class="collapse">
        <div class="col m-0 p-0 text-center">
            Not gonna showing here.
        </div>
    </div>
</div>