@extends('layout.webgl')
@section('style2')
<style>

#main_menu a{
    color: #222;
    text-decoration: none;
    font-size:22px;
    font-family:monospace;
    text-shadow: 0 0 4px #ffffff;
}
#main_menu a:hover{
    color: #ffa0a0;
}
div.modal-content{
    padding:9px 15px;
    border:0px solid #eee;
    background-color: #00000022;
    -webkit-box-shadow: 0 5px 15px rgba(0,0,0,0);
    -moz-box-shadow: 0 5px 15px rgba(0,0,0,0);
    -o-box-shadow: 0 5px 15px rgba(0,0,0,0);
    box-shadow: 0 5px 15px rgba(0,0,0,0);
}


.hide-menu{
    animation-name:close_menu;
    animation-duration: 0.5s;
    animation-timing-function: linear;
    animation-fill-mode: forwards;
}
@keyframes close_menu{
    from{opacity:1;}
    to{opacity:0.2;}
}

.show-menu{
    animation-name:show_menu;
    animation-duration: 0.5s;
    animation-timing-function: linear;
    animation-fill-mode: forwards;
}
@keyframes show_menu{
    from{opacity:0.2;}
    to{opacity:1;}
}
@media only screen and (max-width: 600px) {
    @keyframes show_menu{
        from{top:50px;opacity:0;}
        to{top:0px;opacity:1;}
    }
    @keyframes close_menu{
        from{top:0px;opacity:1;}
        to{top:50px;opacity:0;}
    }
}


.fullscreen{
    position: absolute;
    top:0;
    left:0;
    width: 100%;
    height: 100vh;
    margin:0;
    padding:0;
}

#main_modal {
    transition: opacity 0.5s linear;
    z-index: 10;
}

.hidden {
  display: none;
}

.visuallyhidden {
  opacity: 0;
}
.visuallyvisible {
  opacity: 1;
}

.blur-effect{
    -webkit-filter: blur(4px);
    -moz-filter: blur(4px);
    -o-filter: blur(4px);
    -ms-filter: blur(4px);
    filter: blur(4px);
    filter: url("https://gist.githubusercontent.com/amitabhaghosh197/b7865b409e835b5a43b5/raw/1a255b551091924971e7dee8935fd38a7fdf7311/blur".svg#blur);
    filter:progid:DXImageTransform.Microsoft.Blur(PixelRadius='4');
}

#webgl_canvas{
    transition: opacity 0.3s linear,0.4s filter linear;

}

.modal-card{
    border:0px solid #eee;
    background-color: #77553322;
    /* -webkit-box-shadow: 0 5px 15px rgba(0,0,0,0);
    -moz-box-shadow: 0 5px 15px rgba(0,0,0,0);
    -o-box-shadow: 0 5px 15px rgba(0,0,0,0);
    box-shadow: 0 5px 15px rgba(0,0,0,0); */

    /* box-shadow:  0 0 40px 0 rgba(0, 0, 0, 0.1), 0 0 10px 0 rgba(0, 0, 0, 0.1); */
    max-height: 100vh;
}

#modal_body{
    transition: all 0.5s linear;
}


</style>
@endsection

@section('content2')

<div class="row fullscreen">
    <div class="col-md-4 col-sm-12 mt-5 pt-5 ml-5 pl-5 show-menu align-self-center"  id="main_menu">
        <a href="#" class="modal-trigger" id="a_sieunguoimay" style="font-size: 35px; font-weight:bold;">Sieunguoimay</a><br>
        <a href="#" class="modal-trigger" id="a_game_engine">Game Engine</a><br>
        <a href="#" class="modal-trigger" id="a_coolthings_notes">Notes on Cool Things</a><br>
        <a href="#" class="modal-trigger" id="a_download_cv">Download CV</a><br>
        <a href="#" id="a_fullscreen" >Open Fullscreen</a><br>
    </div>
</div>


<div class="row hidden visuallyhidden fullscreen justify-content-center" id="main_modal">
    <div class="col-lg-6 col-md-8 col-sm-12 align-self-center">
        <div class="card modal-card" >
            <div class="card-title p-2 mb-0 text-center border-bottom">
                <div class="row justify-content-center">
                    <div class="col-1" >
                        <span id="span_btn_back_modal">
                            <button type="button" id="btn_back_modal" class="close d-inline  p-1" >
                                <i class="fas fa-arrow-left" style="font-size:15px"></i>
                            </button>
                        </span>
                    </div>
                    <div class="col-10 mr-0 pr-0">
                        <h3 id="modal_title">Cool Technologies</h3>
                    </div>
                    <div class="col-1 ml-0 pl-0 text-center">
                        <button type="button" id="close_main_modal" class="close d-inline mr-2 mt-1" >
                            <span>&times;</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-body" id="modal_body" style="overflow-y: auto;">
                <div class="container">
                    <div class="row justify-content-center">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script2')
<script>


var DirectoryManager = {
    currentPath:"/home",
    currentPathName:"",
    goInto(name,displayName){
        this.currentPathName = name;
        this.currentPath+='/'+this.currentPathName;
        console.log(this.currentPath);
        console.log(this.currentPathName);
        setDisplayName(displayName);
    },
    back(){
        if(this.currentPath!="/home"){
            var pos = this.currentPath.lastIndexOf('/');
            this.currentPath = this.currentPath.slice(0,pos);
            pos = this.currentPath.lastIndexOf('/');
            this.currentPathName = this.currentPath.slice(pos+1,this.currentPath.length);
            
            console.log(this.currentPath);
            console.log(this.currentPathName,pos+1);
        }
    },
    gotoRoot(){
        this.currentPath = "/home";
        this.currentPathName = ""
        console.log(this.currentPath);
        console.log(this.currentPathName);
    },
    isRoot(){
        return (this.currentPath=="/home");
    },
    changeDirectory(name){
        var data = {name:name};

        $.post('/menu',data,function(response){
            $('#modal_body').html(response.html);
            $('#modal_title').html($('#'+data.name).text());

            if(showElement(modal))
                modalShowingFlag = true;
        },"json");

    }
};

$('#btn_back_modal').on('click',function(){
    DirectoryManager.back();
    if(!DirectoryManager.isRoot()){
        DirectoryManager.changeDirectory(DirectoryManager.currentPathName);
    }else{
        closeModal();
    }
});

// Get the modal
var modal = document.getElementById('main_modal');
//setupBackButton(false);
showButton(true);

function showButton(show){
    if(show)
        $('#span_btn_back_modal').show();
    else
        $('#span_btn_back_modal').hide();
}
function setDisplayName(displayName){
    $('#modal_title').html(displayName);
}

/*On menu item clicked*/
$('.modal-trigger').on('click',function(){

    if($('#main_menu').hasClass('show-menu')) $('#main_menu').toggleClass('show-menu');
    if(!$('#main_menu').hasClass('hide-menu')) $('#main_menu').toggleClass('hide-menu');
    
    DirectoryManager.goInto($(this).attr('id'),$(this).text());
    DirectoryManager.changeDirectory(DirectoryManager.currentPathName);

});

$('#main_modal').on('transitionend',function(e){
    if(e.target == this){
        var burring = $('#webgl_canvas').hasClass('blur-effect');
        if(burring!=modalShowingFlag)
            $('#webgl_canvas').toggleClass('blur-effect');
    }
});


/*Trigger Close the modal*/
var modalShowingFlag = false;
function closeModal(){
    if(hideElement(modal)){
        if(!$('#main_menu').hasClass('show-menu')) $('#main_menu').toggleClass('show-menu');
        if($('#main_menu').hasClass('hide-menu'))$('#main_menu').toggleClass('hide-menu');
        modalShowingFlag = false;
        DirectoryManager.gotoRoot();
    }
}

window.onclick = function(event) {
    if (event.target == modal) {
        closeModal();
    }
}
$('#close_main_modal').on('click',function(){
    closeModal();
});





var fullscreen = false;
$('#a_fullscreen').on('click',function(){
    if(fullscreen){
        closeFullscreen();
        fullscreen = false;
        $('#a_fullscreen').text('Open Fullscreen');
    }
    else{
        fullscreen = true;
        openFullscreen();
        $('#a_fullscreen').text('Close Fullscreen');
    }
});
/* Get the documentElement (<html>) to display the page in fullscreen */
    var elem = document.documentElement;

function openFullscreen() {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) { /* Firefox */
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE/Edge */
    elem.msRequestFullscreen();
  }
}
/* Close fullscreen */
function closeFullscreen() {
  if (document.exitFullscreen) {
    document.exitFullscreen();
  } else if (document.mozCancelFullScreen) { /* Firefox */
    document.mozCancelFullScreen();
  } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
    document.webkitExitFullscreen();
  } else if (document.msExitFullscreen) { /* IE/Edge */
    document.msExitFullscreen();
  }
}

// modal.addEventListener('webkitAnimationEnd',function( event ) { myBox.style.display = 'none'; }, false);
// modal.addEventListener('animationend', function(e) {
//     // modal.classList.add('hidden');
//     if(!$('#main-modal').is(':hidden'))
//         $('#main-modal').modal('hide');
// }, {
//     capture: false,
//     once: true,
//     passive: false
// });
// When the user clicks anywhere outside of the modal, close it
// $('#main-modal'). on('show.bs.modal', function() {

// });
function showElement(element,callback=null){
    if (element.classList.contains('hidden')) {
        element.classList.remove('hidden');
        setTimeout(function () {
            element.classList.remove('visuallyhidden');
            if(callback)
                callback();
        }, 20);
        return true;
    }
    return false;
}
function hideElement(element,callback=null){
    if (!element.classList.contains('hidden')){

        element.classList.add('visuallyhidden');    
        element.addEventListener('transitionend', function(e) {
            element.classList.add('hidden');
            // $('#main-modal').modal('hide');
            if(callback)
               callback();
        }, {
            capture: false,
            once: true,
            passive: false
        });
        return true;
    }
    return false;
}
</script>
@endsection
