<style>
.github-repos p, label{
    margin-bottom: 0px;
}
.github-repos .card a{
    color:#b55;
}
.github-repos .card{
    background-color:#ffffff77;
    border:0;
}
.github-repos .card:hover{
    background-color:#ffffffcc;
}
</style>
<div class="container-fluid github-repos">
    <div class="row">
        <div class="col-3 mt-3 justify-content-center">
            <img src="{{$userData['avatar_url']}}" style="width:100%"/>
        </div>
        <div class="col-6">
            <h3>Github Profile</h3>
            <label><strong>Display Name:</strong> {{$userData['login']}}</label>
            <label><strong>User Name:</strong> {{$userData['name']}}</label>
            <label><strong>Bio:</strong> {{$userData['bio']}}</label>
            <label><strong>Blog:</strong> <a href="{{$userData['blog']}}">{{$userData['blog']}}</a></label>
            <p><a href="https://github.com/sieunguoimay">Visit Github <i class="fas fa-share" style="font-size:10px"></i></a></p>
        </div>
    </div>
    <div class="row">
        <div class="col">
            @foreach($reposData as $repo)
            <div class="col-12">
                <div class="card mb-2">
                    <div class="card-title pt-3 pl-4 mb-0">
                        <h4><a href="{{$repo['html_url']}}">{{$repo['name']}}</a></h4>
                    </div>
                    <div class="card-body m-0 pt-0">
                        @if($repo['description']!=null)
                            <p><strong>Description: </strong> {{$repo['description']}}</p>
                        @endif
                        <p><label>Clone URL: <label> <a href="{{$repo['clone_url']}}">{{$repo['clone_url']}}</a></p>
                        <p><label>Created at: <label> {{$repo['created_at']}}</p>
                        <p><label>Pushed at: <label> {{$repo['pushed_at']}}</p>
                        <p><label>Default branch: <label> {{$repo['default_branch']}}</p>
                        <p><label>Size: <label> {{$repo['size']}}kB</p>
                        <p><label>Language : <label> {{$repo['language']}}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>