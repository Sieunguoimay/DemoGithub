<div class="container-fluid">
    <div class="row ml-1">
        <h4><a href="https://www.youtube.com/channel/UCFAKMz9lrOy0be078UZeOng" style="color:#222">Sieu Nguoi May Channel <i class="fas fa-share" style="font-size:14px;"></i></a></h4>
    </div>
    <div class="row mb-4 ml-1">
        <h5>Featured videos</h5>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12" style="width:100%;height:56.25%;">   
            <iframe width="100%" height="100%" src="https://www.youtube.com/embed/eZ5So0d1l5E?controls=0" 
                frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>        
        </div>
        <div class="col-md-6 col-sm-12">  
            This is my lastest uploaded video on youtube.
        </div>
    </div>
</div>


