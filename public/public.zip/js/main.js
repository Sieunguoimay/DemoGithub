function main(){
    var canvas = document.getElementById('webgl_canvas');
    canvas.addEventListener('mousedown',function(e){
        GraphicsManager.OnMouseDown(e.clientX,e.clientY);
    });
    var gl = canvas.getContext("webgl");
    if(!gl){
        console.log('Failed to get the rendering context for WebGL');
        return;
    }

    GraphicsManager.Init(gl);
    gameloop(gl);

}

function gameloop(gl){
    var start = null;
    function step(currentTime){
        if (!start) start = currentTime;
        var deltaTime = currentTime - start;

        resize(gl.canvas);
        GraphicsManager.Update(deltaTime);
        GraphicsManager.Render();

        window.requestAnimationFrame(step);
    }
    window.requestAnimationFrame(step);
}
function resize(canvas) {
    // Lookup the size the browser is displaying the canvas.
    var displayWidth  = canvas.clientWidth;
    var displayHeight = canvas.clientHeight;

    // Check if the canvas is not the same size.
    if (canvas.width  !== displayWidth ||
        canvas.height !== displayHeight) {

        // Make the canvas the same size
        canvas.width  = displayWidth;
        canvas.height = displayHeight;

        GraphicsManager.OnCanvasResize(displayWidth,displayHeight);
    }
}



/*Trigger of everything*/
window.onload = main;
